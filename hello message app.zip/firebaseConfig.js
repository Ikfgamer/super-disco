// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA7EoBq5HpAcAHIJhj3i4cOPJGUimMt8Ak",
  authDomain: "hello-message-caa48.firebaseapp.com",
  projectId: "hello-message-caa48",
  storageBucket: "hello-message-caa48.firebasestorage.app",
  messagingSenderId: "36834310693",
  appId: "1:36834310693:web:65bad3d79f457aff81ddcc",
  measurementId: "G-HYWKBD819C"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
